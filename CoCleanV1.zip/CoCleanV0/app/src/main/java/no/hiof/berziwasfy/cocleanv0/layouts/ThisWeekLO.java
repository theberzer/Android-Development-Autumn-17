package no.hiof.berziwasfy.cocleanv0.layouts;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.helperClasses.TaskToPersonAdapter;
import no.hiof.berziwasfy.cocleanv0.models.Person;
import no.hiof.berziwasfy.cocleanv0.models.Room;
import no.hiof.berziwasfy.cocleanv0.models.TaskList;

public class ThisWeekLO extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private ArrayList<no.hiof.berziwasfy.cocleanv0.models.Task> tasks = new ArrayList<>();
    private ArrayList<Person> persons = new ArrayList<>();
    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private Person person;
    private TextView userName;
    private TextView userEmail;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_this_week_lo);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        navigationView = findViewById(R.id.nav_view);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        authentication();

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.thisweek) {
            Intent intent = new Intent(this, ThisWeekLO.class);
            startActivity(intent);
        } else if (id == R.id.apartment) {
            Intent intent = new Intent(this, ApartmentLO.class);
            startActivity(intent);
        } else if (id == R.id.tasks) {
            Intent intent = new Intent(this, TasksLO.class);
            startActivity(intent);
        } else if (id == R.id.settings) {
            Intent intent = new Intent(this, LogInNewUserLO.class);
            startActivity(intent);
        } else if (id == R.id.nav_sign_out) {
            AuthUI.getInstance()
                    .signOut(this)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        public void onComplete(@NonNull Task<Void> task) {
                            Intent intent = new Intent(getApplicationContext(), MainLO.class);
                            startActivity(intent);
                        }
                    });
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    protected void onPause() {
        super.onPause();
    }


    public void authentication() {
        currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            DatabaseReference mPersonReference = mDatabase.child("/users/").child(currentUser.getUid());
            ValueEventListener personListner = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        person = dataSnapshot.getValue(Person.class);
                        if (person != null) {
                            getLists();
                            userName = navigationView.getHeaderView(0).findViewById(R.id.userName);
                            userEmail = navigationView.getHeaderView(0).findViewById(R.id.userEmail);
                            String name = person.getfName() + " " + person.getlName();
                            userName.setText(name);
                            userEmail.setText(currentUser.getEmail());
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    Log.w("failedSnap", "Failed to read value.", error.toException());
                }
            };
            mPersonReference.addValueEventListener(personListner);
        }
    }

    public void getLists() {
        DatabaseReference mTaskListReference = mDatabase.child("/apartments/").child(person.getApartment()).child("/sections/").child(person.getSection()).child("/tasklists/");
        ValueEventListener taskListListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot != null) {
                            TaskList taskList = snapshot.getValue(TaskList.class);
                            getTasks(taskList);
                        }
                    }
                }
                getRooms();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mTaskListReference.addValueEventListener(taskListListener);
    }

    public void getRooms() {
        DatabaseReference mRoomReference = mDatabase.child("/apartments/").child(person.getApartment()).child("/sections/").child(person.getSection()).child("/rooms/");
        ValueEventListener roomListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot != null) {
                            Room room = snapshot.getValue(Room.class);
                            getPersons(room);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mRoomReference.addValueEventListener(roomListener);
    }

    public void getPersons(Room room) {
        String uid = room.getPerson();
        DatabaseReference mPersonReference = mDatabase.child("/users/").child(uid);
        ValueEventListener personListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Person person = dataSnapshot.getValue(Person.class);
                    persons.add(person);
                }
                getThisWeekTasks(Calendar.WEEK_OF_YEAR);
            }


            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mPersonReference.addValueEventListener(personListener);

    }

    public void getTasks(TaskList taskList) {
        String taskListName = taskList.getName();
        DatabaseReference mTaskReference = mDatabase.child("/apartments/").child(person.getApartment()).child("/sections/").child(person.getSection()).child("/tasklists/").child(taskListName).child("/tasks/");

        ValueEventListener taskListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot != null) {
                            no.hiof.berziwasfy.cocleanv0.models.Task task = snapshot.getValue(no.hiof.berziwasfy.cocleanv0.models.Task.class);
                            tasks.add(task);

                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mTaskReference.addValueEventListener(taskListener);
    }

    public void getThisWeekTasks(int weekNumber) {
        ArrayList<no.hiof.berziwasfy.cocleanv0.models.Task> tempTasks = tasks;
        for (int i = 1; i <= weekNumber; i++) {
            no.hiof.berziwasfy.cocleanv0.models.Task tempTask;
            try {
                tempTask = tempTasks.get(tempTasks.size() - 1);
                tempTasks.add(0, tempTask);
                tempTasks.remove(tempTasks.size() - 1);
            } catch (ArrayIndexOutOfBoundsException e) {
                return;
            }

        }
        tasks = tempTasks;
        createRV();
    }

    public void createRV() {
        RecyclerView rvTasksToPerson = findViewById(R.id.personTaskRV);
        TaskToPersonAdapter adapter = new TaskToPersonAdapter(this, persons, tasks);
        rvTasksToPerson.setAdapter(adapter);
        rvTasksToPerson.setLayoutManager(new LinearLayoutManager(this));
    }


}
