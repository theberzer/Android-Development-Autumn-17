package no.hiof.berziwasfy.cocleanv0.fragments;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.layouts.LogInNewUserLO;
import no.hiof.berziwasfy.cocleanv0.models.Section;


public class FoundApartmentFragment extends Fragment {
    View view;
    private Spinner sectionSpinner;
    private DatabaseReference mSectionReference;
    private DatabaseReference mDatabase;
    private ArrayList<String> sections = new ArrayList<>();
    private Spinner sectionsNameSpinner;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_found_apartment, container, false);
        sectionSpinner = view.findViewById(R.id.sectionSpinner);
        mDatabase = FirebaseDatabase.getInstance().getReference();

        populateSection();
        //New Section
        view.findViewById(R.id.newSectionBtn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                NewSectionFragment fragment = new NewSectionFragment();
                getFragmentManager().beginTransaction().replace(R.id.roomFragmentFrame, fragment).commit();
            }
        });

        //Found Section
        view.findViewById(R.id.selectSectionBtn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                FoundSectionFragment fragment = new FoundSectionFragment();
                getFragmentManager().beginTransaction().replace(R.id.roomFragmentFrame, fragment).commit();

                ((LogInNewUserLO) getActivity()).setSection(sectionSpinner.getSelectedItem().toString() + " ");

            }
        });
        return view;
    }

    public void populateSection() {
        String apartment = ((LogInNewUserLO) getActivity()).getApartment();
        if (apartment == null) {
            Toast toast = Toast.makeText(getActivity().getApplicationContext(), "Sorry, something went wrong, try again", Toast.LENGTH_SHORT);
            toast.show();
            startActivity(new Intent(getActivity().getApplicationContext(), LogInNewUserLO.class));
        } else {
            mSectionReference = mDatabase.child("/apartments/").child(apartment).child("/sections/");
            ValueEventListener sectionListner = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot sectionSnapshot : dataSnapshot.getChildren()) {
                            if (sectionSnapshot != null) {
                                Section section = sectionSnapshot.getValue(Section.class);
                                if (section != null) {
                                    try {
                                        String sectionName = section.getName().split(" ")[0];
                                        sections.add(sectionName);
                                    } catch (NullPointerException e) {
                                        Toast.makeText(getActivity().getApplicationContext(),
                                                "Sorry there seems to be a problem lets try this again",
                                                Toast.LENGTH_LONG).show();
                                        Intent intent = new Intent(getActivity().getApplicationContext(), LogInNewUserLO.class);
                                        startActivity(intent);
                                    }
                                }

                            }

                        }
                        sectionsNameSpinner = view.findViewById(R.id.sectionSpinner);

                        String[] apartmentName = sections.toArray(new String[0]);
                        ((LogInNewUserLO) getActivity()).setSections(sections);
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), R.layout.support_simple_spinner_dropdown_item, apartmentName);
                        sectionsNameSpinner.setAdapter(adapter);
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    Log.w("failedSnap", "Failed to read value.", error.toException());
                }
            };
            mSectionReference.addValueEventListener(sectionListner);
        }
    }
}
