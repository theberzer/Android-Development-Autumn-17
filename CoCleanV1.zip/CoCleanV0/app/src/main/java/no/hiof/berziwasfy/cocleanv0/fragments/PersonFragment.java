package no.hiof.berziwasfy.cocleanv0.fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import no.hiof.berziwasfy.cocleanv0.R;


public class PersonFragment extends Fragment {
    String picturePath;
    TextView fragmentName;
    TextView roomNr;

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_person, parent, false);


        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {


    }

    public void setText(String name, String roomNr) {
        TextView fName = view.findViewById(R.id.person_name);
        fName.setText(name);
        TextView fRoomNr = view.findViewById(R.id.person_room);
        fRoomNr.setText(roomNr);
    }


}
