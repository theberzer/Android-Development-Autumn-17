package no.hiof.berziwasfy.cocleanv0.fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.helperClasses.AddRoomToSection;
import no.hiof.berziwasfy.cocleanv0.helperClasses.AddSectionToApartment;
import no.hiof.berziwasfy.cocleanv0.layouts.LogInNewUserLO;
import no.hiof.berziwasfy.cocleanv0.models.Person;


public class NewSectionFragment extends Fragment {
    View view;
    private EditText roomnr;
    private EditText sectionnr;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_new_section, container, false);
        sectionnr = view.findViewById(R.id.sectionNumber);
        roomnr = view.findViewById(R.id.roomNumber);


        view.findViewById(R.id.btnRegister2).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ((LogInNewUserLO) getActivity()).setSection(sectionnr.getText().toString());
                ((LogInNewUserLO) getActivity()).setRoom(roomnr.getText().toString());

                String fName = ((LogInNewUserLO) getActivity()).getfNameString();
                String lName = ((LogInNewUserLO) getActivity()).getlNameString();
                String apartment = ((LogInNewUserLO) getActivity()).getApartment();
                String section = ((LogInNewUserLO) getActivity()).getSection() + " ";
                String roomnr = ((LogInNewUserLO) getActivity()).getRoom() + " ";
                String uid = ((LogInNewUserLO) getActivity()).getUid();

                new Person(uid, fName, lName, roomnr, section, apartment);

                if (!((LogInNewUserLO) getActivity()).getSections().contains(section)) {
                    new AddSectionToApartment(section, apartment);
                    new AddRoomToSection(roomnr, section, apartment, uid);
                } else {
                    new AddRoomToSection(roomnr, section, apartment, uid);
                }
            }
        });

        return view;
    }
}
