package no.hiof.berziwasfy.cocleanv0.models;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by berzi on 16/10/2017.
 */
@IgnoreExtraProperties
public class Apartment {
    private String name;
    private Map<String, Object> sections = new HashMap<>();
    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();


    public Apartment(String name, String section, String room, String uid) {
        this.name = name;
        Section newSection = new Section(section, name);
        sections.put(newSection.getName(), newSection);
        Room newRoom = new Room(room, section, name);
        newSection.addRoom(newRoom);


        //Database update
        Map<String, Object> apartmentInfoMap = new HashMap<>();
        apartmentInfoMap.put("name", name);

        Map<String, Object> apartmentUpdate = new HashMap<>();
        apartmentUpdate.put("/apartments/" + name, apartmentInfoMap);
        mDatabase.updateChildren(apartmentUpdate);


        Map<String, Object> sectionInfoMap = new HashMap<>();
        sectionInfoMap.put("name", newSection.getName());

        Map<String, Object> sectionUpdate = new HashMap<>();
        sectionUpdate.put("/apartments/" + name + "/sections/" + newSection.getName(), sectionInfoMap);
        mDatabase.updateChildren(sectionUpdate);

        Map<String, Object> roomInfoMap = new HashMap<>();
        roomInfoMap.put("name", newRoom.getName());
        roomInfoMap.put("person", uid);

        mDatabase.child("/apartments/").child(name).child("/sections/").child(newSection.getName()).child("/rooms/").child(newRoom.getName()).updateChildren(roomInfoMap);
    }

    public Apartment() {
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Map<String, Object> getSections() {
        return sections;
    }

    public void setSections(Map<String, Object> sections) {
        this.sections = sections;
    }

    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("name", name);
        result.put("sections", sections);

        return result;
    }

}
