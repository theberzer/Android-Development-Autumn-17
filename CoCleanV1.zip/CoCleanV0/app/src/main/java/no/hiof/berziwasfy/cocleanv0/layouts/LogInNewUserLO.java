package no.hiof.berziwasfy.cocleanv0.layouts;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.fragments.FoundApartmentFragment;
import no.hiof.berziwasfy.cocleanv0.fragments.NewApartmentFragment;
import no.hiof.berziwasfy.cocleanv0.models.Apartment;

public class LogInNewUserLO extends AppCompatActivity {


    private DatabaseReference mSectionReference;
    private EditText fName;
    private EditText lName;
    private Spinner apartmentNameSpinner;
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference mDatabase;
    private ArrayList<String> apartments = new ArrayList<>();
    private ArrayList<String> sections = new ArrayList<>();
    private String apartment;
    private String section;
    private String room;
    private String fNameString;
    private String lNameString;
    private String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_log_in_new_user);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();


        //inputs
        fName = findViewById(R.id.fName);
        lName = findViewById(R.id.lName);
        apartmentNameSpinner = findViewById(R.id.apartmentSpinner);


        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                currentUser = firebaseAuth.getCurrentUser();
                uid = currentUser.getUid();

            }
        };
        populateApartment();

        //Fragment Buttons
        //New Apartment
        findViewById(R.id.newApartmentBtn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                NewApartmentFragment fragment = new NewApartmentFragment();
                getFragmentManager().beginTransaction().replace(R.id.sectionFragmentFrame, fragment).commit();

                fNameString = fName.getText().toString();
                lNameString = lName.getText().toString();
            }
        });

        //Found Apartment
        findViewById(R.id.selectApartmentBtn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                FoundApartmentFragment fragment = new FoundApartmentFragment();
                getFragmentManager().beginTransaction().replace(R.id.sectionFragmentFrame, fragment).commit();

                apartment = apartmentNameSpinner.getSelectedItem().toString();
                fNameString = fName.getText().toString();
                lNameString = lName.getText().toString();

            }
        });


    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
        currentUser = mAuth.getCurrentUser();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    public void populateApartment() {
        mSectionReference = mDatabase.child("/apartments/");
        ValueEventListener sectionListner = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot apartmentSnapshot : dataSnapshot.getChildren()) {
                        if (apartmentSnapshot != null) {
                            Apartment apartment = apartmentSnapshot.getValue(Apartment.class);
                            try {
                                apartments.add(apartment.getName());
                            } catch (NullPointerException e) {
                                Toast.makeText(getApplicationContext(),
                                        "Sorry there seems to be a problem lets try this again",
                                        Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(getApplicationContext(), LogInNewUserLO.class);
                                startActivity(intent);
                            }
                        }
                    }
                    apartmentNameSpinner = findViewById(R.id.apartmentSpinner);

                    String[] apartmentName = apartments.toArray(new String[0]);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, apartmentName);
                    apartmentNameSpinner.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mSectionReference.addValueEventListener(sectionListner);
    }

    public String getApartment() {
        return apartment;
    }

    public void setApartment(String apartment) {
        this.apartment = apartment;
    }

    public ArrayList<String> getApartments() {
        return apartments;
    }


    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getfNameString() {
        return fNameString;
    }

    public String getlNameString() {
        return lNameString;
    }

    public String getUid() {
        return uid;
    }

    public ArrayList<String> getSections() {
        return sections;
    }

    public void setSections(ArrayList<String> sections) {
        this.sections = sections;
    }
}
