package no.hiof.berziwasfy.cocleanv0.models;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by berzi on 16/10/2017.
 */

public class TaskList {
    private int id;
    private String name;
    private String section;
    private Map<String, Object> tasks = new HashMap<>();
    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference mPersonReference;
    private Person person;


    public TaskList() {
    }

    public TaskList(String taskListName, final String taskListSection) {
        this.name = taskListName;
        this.section = taskListSection;


        mPersonReference = mDatabase.child("/users/").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        ValueEventListener personListner = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    person = dataSnapshot.getValue(Person.class);

                    //Database update
                    Map<String, Object> taskListInfoMap = new HashMap<>();
                    taskListInfoMap.put("name", name);
                    taskListInfoMap.put("section", section);

                    Map<String, Object> taskListUpdate = new HashMap<>();
                    taskListUpdate.put("/apartments/" + person.getApartment() + "/sections/" + taskListSection + "/tasklists/" + name, taskListInfoMap);
                    mDatabase.updateChildren(taskListUpdate);

                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mPersonReference.addValueEventListener(personListner);


    }

    public void addTaskToList(Task task) {
        tasks.put("tasks", task);
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public Map<String, Object> getTasks() {
        return tasks;
    }

    public void setTasks(Map<String, Object> tasks) {
        this.tasks = tasks;
    }

    public DatabaseReference getmDatabase() {
        return mDatabase;
    }

    public void setmDatabase(DatabaseReference mDatabase) {
        this.mDatabase = mDatabase;
    }
}
