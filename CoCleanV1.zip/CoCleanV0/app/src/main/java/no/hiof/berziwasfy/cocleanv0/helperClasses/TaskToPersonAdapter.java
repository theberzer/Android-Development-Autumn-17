package no.hiof.berziwasfy.cocleanv0.helperClasses;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.models.Person;
import no.hiof.berziwasfy.cocleanv0.models.Task;

/**
 * Created by berzi on 30/11/2017.
 */

// Create the basic adapter extending from RecyclerView.Adapter
// Note that we specify the custom ViewHolder which gives us access to our views
public class TaskToPersonAdapter extends
        RecyclerView.Adapter<TaskToPersonAdapter.ViewHolder> {

    public TaskToPersonAdapter.ViewHolder viewHolderC;
    private List<Person> mPersons;
    private List<Task> mtasks;
    private Context mContext;
    public TaskToPersonAdapter(Context context, List<Person> persons, List<Task> tasks) {
        mContext = context;
        mPersons = persons;
        mtasks = tasks;
    }

    public List<Person> getmPersons() {
        return mPersons;
    }

    public List<Task> getMtasks() {
        return mtasks;
    }

    public Context getmContext() {
        return mContext;
    }

    @Override
    public TaskToPersonAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);


        return new ViewHolder(inflater.inflate(R.layout.fragment_persontask, parent, false));
    }

    @Override
    public void onBindViewHolder(final TaskToPersonAdapter.ViewHolder viewHolder, int position) {
        Person person;
        Task task;
        try {
            person = mPersons.get(position);
        } catch (IndexOutOfBoundsException e) {
            person = new Person("Free Task");
        }
        try {
            task = mtasks.get(position);
        } catch (IndexOutOfBoundsException e) {
            task = new Task("Free Week");
        }
        viewHolderC = viewHolder;

        // Set item views based on your views and data model
        TextView personName = viewHolder.personName;
        TextView taskName = viewHolder.taskName;

        personName.setText(person.getfName());
        taskName.setText(task.getName());

        DatabaseReference mPersonReference = FirebaseDatabase.getInstance().getReference().child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        ValueEventListener personListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    {
                        Person person = dataSnapshot.getValue(Person.class);
                        Task tempTask;
                        try {
                            tempTask = mtasks.get(viewHolder.getAdapterPosition());
                            DatabaseReference mTaskReference = FirebaseDatabase.getInstance().getReference().child("/apartments/").child(person.getApartment())
                                    .child("/sections/").child(person.getSection()).child("/tasklists/").child("Section " + person.getSection() + "Weekly").child("/tasks/").child(tempTask.getName());
                            ValueEventListener taskListener = new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.exists()) {
                                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                            if (snapshot != null) {
                                                Task task = snapshot.getValue(Task.class);
                                                CheckBox done = viewHolderC.done;
                                                if (task != null) {
                                                    done.setChecked(task.isDone());
                                                }
                                            }
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError error) {
                                    Log.w("failedSnap", "Failed to read value.", error.toException());
                                }
                            };
                            mTaskReference.addValueEventListener(taskListener);
                        } catch (IndexOutOfBoundsException e) {
                            Log.d("StackTrace", e.toString());
                        }


                    }
                }
            }


            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mPersonReference.addValueEventListener(personListener);


    }

    // Returns the total count of items in the list
    @Override
    public int getItemCount() {
        if (mPersons.size() > mtasks.size()) {
            return mPersons.size();
        } else {
            return mtasks.size();
        }
    }

    // Provide a direct reference to each of the views within a data item
    // Used to cache the views within the item layout for fast access
    public class ViewHolder extends RecyclerView.ViewHolder {
        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        public TextView personName;
        public TextView taskName;
        public CheckBox done;

        // We also create a constructor that accepts the entire item row
        // and does the view lookups to find each subview
        public ViewHolder(View itemView) {
            // Stores the itemView in a public final member variable that can be used
            // to access the context from any ViewHolder instance.
            super(itemView);

            personName = itemView.findViewById(R.id.personName);
            taskName = itemView.findViewById(R.id.taskName);
            done = itemView.findViewById(R.id.doneCheckBox);
        }
    }
}