package no.hiof.berziwasfy.cocleanv0.models;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by berzi on 16/10/2017.
 */

public class Task {
    private String name;
    private String section;
    private String person;
    private String taskList;
    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference mPersonReference;
    private boolean done;

    public Task(String taskName, String taskListName, String section) {
        this.name = taskName;
        this.section = section + " ";
        this.taskList = taskListName;
        this.done = false;
        update();
    }

    public Task() {
    }

    public Task(String taskName) {
        this.name = taskName;
    }

    private void update() {
        mPersonReference = mDatabase.child("/users/").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        ValueEventListener personListner = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Person p = dataSnapshot.getValue(Person.class);

                    if (p != null) {
                        //Database update
                        Map<String, Object> taskListInfoMap = new HashMap<>();
                        taskListInfoMap.put("name", name);
                        taskListInfoMap.put("done", done);

                        Map<String, Object> taskListUpdate = new HashMap<>();
                        taskListUpdate.put("/apartments/" + p.getApartment() + "/sections/" + section + "/tasklists/" + "Section " + section + " " + taskList + "/tasks/" + name, taskListInfoMap);
                        mDatabase.updateChildren(taskListUpdate);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mPersonReference.addValueEventListener(personListner);
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getTaskList() {
        return taskList;
    }

    public void setTaskList(String taskList) {
        this.taskList = taskList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }
}
