package no.hiof.berziwasfy.cocleanv0.helperClasses;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

import no.hiof.berziwasfy.cocleanv0.models.Section;

/**
 * Created by berzi on 29/11/2017.
 */

public class AddSectionToApartment {
    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();

    public AddSectionToApartment(String section, String apartment) {

        Section newSection = new Section(section, apartment);
        Map<String, Object> sectionInfoMap = new HashMap<>();
        sectionInfoMap.put("name", newSection.getName());


        mDatabase.child("/apartments/").child(apartment).child("/sections/").child(newSection.getName()).updateChildren(sectionInfoMap);
    }
}
