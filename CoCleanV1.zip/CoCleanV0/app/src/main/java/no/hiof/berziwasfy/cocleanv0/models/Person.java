package no.hiof.berziwasfy.cocleanv0.models;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

/**
 * Created by berzi on 16/10/2017.
 */

public class Person {
    public static ArrayList<Person> personsInApartment = new ArrayList<>();
    private String id;
    private String fName;
    private String lName;
    private String room;
    private String apartment;
    private String section;
    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();


    public Person(String uid, String fName, String lName, String room, String section, String apartment) {
        this.room = room;
        this.apartment = apartment;
        this.section = section;
        this.fName = fName;
        this.lName = lName;
        this.id = uid;
        mDatabase.child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(this);
        personsInApartment.add(this);
    }

    public Person() {
    }


    public Person(String fName) {
        this.fName = fName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getApartment() {
        return apartment;
    }

    public void setApartment(String apartment) {
        this.apartment = apartment;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
}
