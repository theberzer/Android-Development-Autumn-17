package no.hiof.berziwasfy.cocleanv0.helperClasses;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.models.Person;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.ViewHolder> {

    private List<Person> mPersons;
    private Context mContext;
    public PersonAdapter(List<Person> persons, Context context) {
        this.mPersons = persons;
        this.mContext = context;
    }

    public List<Person> getmPersons() {
        return mPersons;
    }

    public void setmPersons(List<Person> mPersons) {
        this.mPersons = mPersons;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    @Override
    public PersonAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        return new ViewHolder(inflater.inflate(R.layout.fragment_person, parent, false));
    }

    @Override
    public void onBindViewHolder(PersonAdapter.ViewHolder viewHolder, int position) {
        Person person = mPersons.get(position);

        // Set item views based on your views and data model
        TextView textViewName = viewHolder.nameTextView;
        TextView textViewRoom = viewHolder.roomTextView;
        textViewName.setText(person.getfName() + " " + person.getlName());
        textViewRoom.setText(person.getRoom());
    }

    @Override
    public int getItemCount() {
        return mPersons.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView nameTextView;
        public TextView roomTextView;

        public ViewHolder(View itemView) {
            super(itemView);

            nameTextView = itemView.findViewById(R.id.person_name);
            roomTextView = itemView.findViewById(R.id.person_room);
        }
    }
}