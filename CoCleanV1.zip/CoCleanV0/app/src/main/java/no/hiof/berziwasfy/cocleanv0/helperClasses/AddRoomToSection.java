package no.hiof.berziwasfy.cocleanv0.helperClasses;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

import no.hiof.berziwasfy.cocleanv0.models.Room;

/**
 * Created by berzi on 29/11/2017.
 */

public class AddRoomToSection {
    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();


    public AddRoomToSection(String room, String section, String apartment, String uid) {
        String section2 = section.split(" ")[0];
        Room newRoom = new Room(room, section2, apartment);

        Map<String, Object> roomInfoMap = new HashMap<>();
        roomInfoMap.put("name", newRoom.getName());
        roomInfoMap.put("person", uid);

        mDatabase.child("/apartments/").child(apartment).child("/sections/").child(section2 + " ").child("/rooms/").child(room).updateChildren(roomInfoMap);

    }
}




