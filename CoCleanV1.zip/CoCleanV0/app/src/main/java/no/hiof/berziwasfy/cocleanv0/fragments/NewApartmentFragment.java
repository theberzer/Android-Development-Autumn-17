package no.hiof.berziwasfy.cocleanv0.fragments;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.helperClasses.AddRoomToSection;
import no.hiof.berziwasfy.cocleanv0.helperClasses.AddSectionToApartment;
import no.hiof.berziwasfy.cocleanv0.layouts.LogInNewUserLO;
import no.hiof.berziwasfy.cocleanv0.layouts.ThisWeekLO;
import no.hiof.berziwasfy.cocleanv0.models.Apartment;
import no.hiof.berziwasfy.cocleanv0.models.Person;


public class NewApartmentFragment extends Fragment {
    View view;
    private EditText apartment;
    private EditText section;
    private EditText roomnr;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_new_apartment, container, false);

        view.findViewById(R.id.btnRegister).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                String fName = ((LogInNewUserLO) getActivity()).getfNameString();
                String lName = ((LogInNewUserLO) getActivity()).getlNameString();
                apartment = view.findViewById(R.id.apartmentName);
                section = view.findViewById(R.id.sectionNumber);
                roomnr = view.findViewById(R.id.roomNumber);
                String uid = ((LogInNewUserLO) getActivity()).getUid();

                new Person(uid, fName, lName, roomnr.getText().toString() + " ", section.getText().toString() + " ", apartment.getText().toString());
                if (!((LogInNewUserLO) getActivity()).getApartments().contains(apartment.getText().toString())) {
                    new Apartment(apartment.getText().toString(), section.getText().toString() + " ", roomnr.getText().toString() + " ", uid);
                } else if (!((LogInNewUserLO) getActivity()).getSections().contains(section.getText().toString())) {
                    new AddSectionToApartment(section.getText().toString() + " ", apartment.getText().toString());
                    new AddRoomToSection(roomnr.getText().toString() + " ", section.getText().toString() + " ", apartment.getText().toString(), uid);

                } else {
                    new AddRoomToSection(roomnr.getText().toString() + " ", section.getText().toString() + " ", apartment.getText().toString(), uid);
                }


                Intent intent = new Intent(getActivity().getApplicationContext(), ThisWeekLO.class);
                startActivity(intent);
            }
        });
        return view;
    }


}
