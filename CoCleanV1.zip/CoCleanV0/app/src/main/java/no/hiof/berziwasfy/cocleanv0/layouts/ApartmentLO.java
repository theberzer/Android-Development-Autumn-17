package no.hiof.berziwasfy.cocleanv0.layouts;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.helperClasses.PersonAdapter;
import no.hiof.berziwasfy.cocleanv0.models.Person;
import no.hiof.berziwasfy.cocleanv0.models.Room;
import no.hiof.berziwasfy.cocleanv0.models.Section;


public class ApartmentLO extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    public ArrayList<Person> persons;
    private DatabaseReference mPersonsReference;
    private DatabaseReference mPersonReference;
    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private TextView userName;
    private TextView userEmail;
    private NavigationView navigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apartment_lo);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        navigationView = findViewById(R.id.nav_view);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        authentication();

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.thisweek) {
            Intent intent = new Intent(this, ThisWeekLO.class);
            startActivity(intent);
        } else if (id == R.id.apartment) {
            Intent intent = new Intent(this, ApartmentLO.class);
            startActivity(intent);
        } else if (id == R.id.tasks) {
            Intent intent = new Intent(this, TasksLO.class);
            startActivity(intent);
        } else if (id == R.id.settings) {
            Intent intent = new Intent(this, LogInNewUserLO.class);
            startActivity(intent);
        } else if (id == R.id.nav_sign_out) {
            AuthUI.getInstance()
                    .signOut(this)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        public void onComplete(@NonNull Task<Void> task) {
                            Intent intent = new Intent(getApplicationContext(), MainLO.class);
                            startActivity(intent);
                        }
                    });
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    protected void onPause() {
        super.onPause();
        Person.personsInApartment.clear();

    }

    public void createRV() {
        RecyclerView rvPersons = findViewById(R.id.rvPersons);
        persons = Person.personsInApartment;
        PersonAdapter adapter = new PersonAdapter(persons, this);
        rvPersons.setAdapter(adapter);
        rvPersons.setLayoutManager(new LinearLayoutManager(this));
    }

    public void authentication() {
        currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            mPersonReference = mDatabase.child("/users/").child(currentUser.getUid());
            ValueEventListener personListner = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        Person person = dataSnapshot.getValue(Person.class);
                        if (person != null) {
                            userName = navigationView.getHeaderView(0).findViewById(R.id.userName);
                            userEmail = navigationView.getHeaderView(0).findViewById(R.id.userEmail);
                            String name = person.getfName() + " " + person.getlName();
                            userName.setText(name);
                            userEmail.setText(currentUser.getEmail());
                            try {
                                getSections(person.getApartment());
                            } catch (NullPointerException e) {
                                Toast.makeText(getApplicationContext(), "No Network Please try again", Toast.LENGTH_LONG).show();
                                startActivity(new Intent(Intent.ACTION_MAIN)
                                        .addCategory(Intent.CATEGORY_HOME)
                                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                            }
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    Log.w("failedSnap", "Failed to read value.", error.toException());
                }
            };
            mPersonReference.addValueEventListener(personListner);
        }
    }

    public void getSections(final String apartment) {
        DatabaseReference mSectionReference = mDatabase.child("/apartments/").child(apartment).child("/sections/");
        ValueEventListener sectionListner = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot != null) {
                            Section section = snapshot.getValue(Section.class);
                            getRooms(apartment, section.getName());
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mSectionReference.addValueEventListener(sectionListner);
    }

    public void getRooms(String apartment, String section) {
        Log.d("HEI!", apartment + " " + section);
        DatabaseReference mRoomReference = mDatabase.child("/apartments/").child(apartment).child("/sections/").child(section).child("/rooms/");
        ValueEventListener roomListner = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot != null) {
                            Room room = snapshot.getValue(Room.class);
                            getPersons(room.getPerson());
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mRoomReference.addValueEventListener(roomListner);
    }

    public void getPersons(String uid) {
        DatabaseReference mTaskReference = mDatabase.child("/users/").child(uid);
        ValueEventListener taskListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Person person = dataSnapshot.getValue(Person.class);
                    if (!Person.personsInApartment.contains(person)) {
                        Person.personsInApartment.add(person);
                        createRV();
                    }
                }
            }


            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mTaskReference.addValueEventListener(taskListener);
    }
}


