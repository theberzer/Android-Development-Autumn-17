package no.hiof.berziwasfy.cocleanv0.layouts;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.models.Person;
import no.hiof.berziwasfy.cocleanv0.models.Section;
import no.hiof.berziwasfy.cocleanv0.models.TaskList;

public class TasksLO extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference mSectionReference;
    private DatabaseReference mTaskListReference;
    private DatabaseReference mTaskList2Reference;
    private ArrayList<String> sectionsList = new ArrayList<>();
    private ArrayList<String> taskListList = new ArrayList<>();
    private Spinner sectionSelect;
    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference mPersonReference;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private Person person;
    private EditText taskListName;
    private EditText taskName;
    private Spinner taskListSelection;
    private TextView userName;
    private TextView userEmail;
    private NavigationView navigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_tasks_lo);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mAuth = FirebaseAuth.getInstance();
        taskListName = findViewById(R.id.tasklistName);
        taskName = findViewById(R.id.taskName);
        taskListSelection = findViewById(R.id.taskListSelection);
        navigationView = findViewById(R.id.nav_view);
        authentication();


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        authentication();

        findViewById(R.id.taskListBtn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new TaskList("Section " + sectionSelect.getSelectedItem().toString() + " " + taskListName.getText().toString(), sectionSelect.getSelectedItem().toString());
                taskListName.setText("");
            }
        });

        findViewById(R.id.taskBtn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String taskList = taskListSelection.getSelectedItem().toString().split(" ")[3];
                String section = taskListSelection.getSelectedItem().toString().split(" ")[1];


                new no.hiof.berziwasfy.cocleanv0.models.Task(taskName.getText().toString(), taskList, section);
                taskName.setText("");
                Toast.makeText(TasksLO.this, "New Task Created", Toast.LENGTH_SHORT).show();
            }
        });

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.thisweek) {
            Intent intent = new Intent(this, ThisWeekLO.class);
            startActivity(intent);
        } else if (id == R.id.apartment) {
            Intent intent = new Intent(this, ApartmentLO.class);
            startActivity(intent);
        } else if (id == R.id.tasks) {
            Intent intent = new Intent(this, TasksLO.class);
            startActivity(intent);
        } else if (id == R.id.settings) {
            Intent intent = new Intent(this, LogInNewUserLO.class);
            startActivity(intent);
        } else if (id == R.id.nav_sign_out) {
            AuthUI.getInstance()
                    .signOut(this)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        public void onComplete(@NonNull Task<Void> task) {
                            Intent intent = new Intent(getApplicationContext(), MainLO.class);
                            startActivity(intent);
                        }
                    });
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        sectionsList.clear();
    }

    public void populateSection() {
        mSectionReference = database.getReference().child("/apartments/").child(person.getApartment()).child("/sections/");
        ValueEventListener sectionListner = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    for (DataSnapshot sectionSnapshot : dataSnapshot.getChildren()) {
                        if (sectionSnapshot != null) {
                            Section section = sectionSnapshot.getValue(Section.class);
                            sectionsList.add(section.getName());
                        }
                    }

                    sectionSelect = findViewById(R.id.sectionSelection);
                    String[] sections = sectionsList.toArray(new String[0]);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, sections);
                    sectionSelect.setAdapter(adapter);

                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mSectionReference.addValueEventListener(sectionListner);

    }

    public void populateTaskList() {
        mTaskListReference = database.getReference().child("/apartments/").child(person.getApartment()).child("/sections/").child("1 ").child("/tasklists/");
        mTaskList2Reference = database.getReference().child("/apartments/").child(person.getApartment()).child("/sections/").child("2 ").child("/tasklists/");
        ValueEventListener taskListListner = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot sectionSnapshot : dataSnapshot.getChildren()) {
                        TaskList tasklist = sectionSnapshot.getValue(TaskList.class);
                        if (tasklist != null) {
                            taskListList.add(tasklist.getName());
                        }
                    }
                    taskListSelection = findViewById(R.id.taskListSelection);
                    String[] taskLists = taskListList.toArray(new String[0]);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, taskListList);
                    taskListSelection.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mTaskListReference.addValueEventListener(taskListListner);
        mTaskList2Reference.addValueEventListener(taskListListner);
    }

    public void authentication() {
        currentUser = mAuth.getCurrentUser();
        mPersonReference = mDatabase.child("/users/").child(currentUser.getUid());
        ValueEventListener personListner = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    person = dataSnapshot.getValue(Person.class);
                    populateSection();
                    populateTaskList();
                    userName = navigationView.getHeaderView(0).findViewById(R.id.userName);
                    userEmail = navigationView.getHeaderView(0).findViewById(R.id.userEmail);
                    String name = person.getfName() + " " + person.getlName();
                    userName.setText(name);
                    userEmail.setText(currentUser.getEmail());

                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("failedSnap", "Failed to read value.", error.toException());
            }
        };
        mPersonReference.addValueEventListener(personListner);
    }


}