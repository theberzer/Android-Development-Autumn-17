package no.hiof.berziwasfy.cocleanv0.models;

import com.google.firebase.database.IgnoreExtraProperties;

/**
 * Created by berzi on 16/10/2017.
 */
@IgnoreExtraProperties
public class Room {
    private String name;
    private String person;
    private String section;
    private String apartment;


    public Room(String name, String section, String apartment) {
        this.name = name;
        this.section = section;
        this.apartment = apartment;
    }

    public Room() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getApartment() {
        return apartment;
    }

    public void setApartment(String apartment) {
        this.apartment = apartment;
    }
}
