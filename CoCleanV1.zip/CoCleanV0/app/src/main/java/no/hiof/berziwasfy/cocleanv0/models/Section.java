package no.hiof.berziwasfy.cocleanv0.models;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by berzi on 16/10/2017.
 */
@IgnoreExtraProperties
public class Section {
    private String name;
    private String apartment;
    private Map<String, Object> rooms = new HashMap<>();
    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();

    public Section(String name, String apartment) {
        this.name = name;
        this.apartment = apartment;
    }

    public Section() {
    }

    public void addRoom(Room rm) {
        rooms.put("rooms", rm);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getApartment() {
        return apartment;
    }

    public void setApartment(String apartment) {
        this.apartment = apartment;
    }

    public Map<String, Object> getRooms() {
        return rooms;
    }

    public void setRooms(Map<String, Object> rooms) {
        this.rooms = rooms;
    }

}
