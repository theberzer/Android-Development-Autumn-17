package no.hiof.berziwasfy.cocleanv0.models;

/**
 * Created by berzi on 16/10/2017.
 */

public class Note {
    private int id;
    private String text;
    private Person creator;

    public Note(String text, Person creator) {
        this.text = text;
        this.creator = creator;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Person getCreator() {
        return creator;
    }

}
