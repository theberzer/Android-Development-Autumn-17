package no.hiof.berziwasfy.cocleanv0.fragments;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import no.hiof.berziwasfy.cocleanv0.R;
import no.hiof.berziwasfy.cocleanv0.helperClasses.AddRoomToSection;
import no.hiof.berziwasfy.cocleanv0.helperClasses.AddSectionToApartment;
import no.hiof.berziwasfy.cocleanv0.layouts.LogInNewUserLO;
import no.hiof.berziwasfy.cocleanv0.models.Person;
import no.hiof.berziwasfy.cocleanv0.models.Room;


public class FoundSectionFragment extends Fragment {
    View view;
    private DatabaseReference mRoomReference;
    private DatabaseReference mDatabase;
    private ArrayList<String> rooms = new ArrayList<>();
    private Spinner roomnr;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_found_section, container, false);
        roomnr = view.findViewById(R.id.roomSpinner);
        mDatabase = FirebaseDatabase.getInstance().getReference();


        populateSection();
        //New Room
        view.findViewById(R.id.newRoomBtn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                FrameLayout fl = view.findViewById(R.id.newRoomFragmentFrame);
                fl.removeAllViews();
                NewRoomFragment fragment = new NewRoomFragment();
                getFragmentManager().beginTransaction().replace(R.id.newRoomFragmentFrame, fragment).commit();


            }
        });

        view.findViewById(R.id.btnRegister).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                ((LogInNewUserLO) getActivity()).setRoom(roomnr.getSelectedItem().toString());
                String fName = ((LogInNewUserLO) getActivity()).getfNameString();
                String lName = ((LogInNewUserLO) getActivity()).getlNameString();
                String apartment = ((LogInNewUserLO) getActivity()).getApartment();
                String section = ((LogInNewUserLO) getActivity()).getSection();
                String roomnr = ((LogInNewUserLO) getActivity()).getRoom();
                String uid = ((LogInNewUserLO) getActivity()).getUid();

                new Person(uid, fName, lName, roomnr, section, apartment);
                new AddRoomToSection(roomnr, section, apartment, uid);
                new AddSectionToApartment(section, apartment);
            }
        });

        return view;
    }

    public void populateSection() {
        String apartment = ((LogInNewUserLO) getActivity()).getApartment();
        String section = ((LogInNewUserLO) getActivity()).getSection();
        if (apartment == null) {
            Toast toast = Toast.makeText(getActivity().getApplicationContext(), "Sorry, something went wrong, try again", Toast.LENGTH_SHORT);
            toast.show();
            startActivity(new Intent(getActivity().getApplicationContext(), LogInNewUserLO.class));
        } else {
            mRoomReference = mDatabase.child("/apartments/").child(apartment).child("/sections/").child(section).child("/rooms/");
            ValueEventListener sectionListner = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot apartmentSnapshot : dataSnapshot.getChildren()) {
                            if (apartmentSnapshot != null) {
                                Room room = apartmentSnapshot.getValue(Room.class);
                                try {
                                    rooms.add(room.getName());
                                } catch (NullPointerException e) {
                                    Toast.makeText(getActivity().getApplicationContext(),
                                            "Sorry there seems to be a problem lets try this again",
                                            Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(getActivity().getApplicationContext(), LogInNewUserLO.class);
                                    startActivity(intent);
                                }
                            }
                        }

                        String[] apartmentName = rooms.toArray(new String[0]);
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity().getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, apartmentName);
                        roomnr.setAdapter(adapter);
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    Log.w("failedSnap", "Failed to read value.", error.toException());
                }
            };
            mRoomReference.addValueEventListener(sectionListner);
        }
    }


}
